# Runnable Harness Example

This directory is a complete ChinaTravel checkout with the current English and Chinese
sandbox databases. The harness is configured for an OpenAI-compatible SGLang server at
`http://127.0.0.1:30000/v1` and the served model name `Qwen3.6-27B`.

From this directory, run:

```bash
uv run python agent_env/scripts/solve_script_with_harness.py
```

The default configuration in `agent_env/config.toml` runs one English `easy` query.
Override the split or query from the command line:

```bash
uv run python agent_env/scripts/solve_script_with_harness.py --split easy --uid <uid>
uv run python agent_env/scripts/solve_script_with_harness.py --split <split> --limit 100 --resume
```

Check the model endpoint before a run:

```bash
curl http://127.0.0.1:30000/v1/models
```

Plans are written to `results/<method>/<uid>.json`. Harness prompts, raw model output,
and per-query evaluation details are written under `agent_env/runs/<method>/`.
