# Team Antarctic penguins — Phase 2 Harness (v1)

Self-contained harness built ON TOP of the official `ChinaTravel_harness_example`
checkout. A custom in-process agent (`harness = "tpcagent"`) runs our
deterministic NeSy planner; the LLM is used ONLY for NL -> DSL translation via
the organizer-served SGLang endpoint.

## How the organizers run it

    python agent_env/scripts/solve_script_with_harness.py --method <method> --split <split>

- `agent_env/config.toml` selects `harness = "tpcagent"`; `--method` / `--split`
  from the CLI override the config (nothing is hard-coded: no split name, no
  query list, no query count, no method name).
- Results: `results/<method>/<uid>.json` for every query.
- LLM: OpenAI-compatible SGLang at `http://127.0.0.1:30000/v1`, model
  `Qwen3.6-27B`, api_key `EMPTY`, thinking disabled (config `[tpcagent]`).

## Runtime budget (5 h / 100 queries)

`agent_env/scripts/tpc_agent_runner.py` enforces a global soft deadline
(4h50m, `total_budget_sec`) plus a per-query cap (170 s). On timeout or any
error the deterministic DB-only fallback plan is emitted, so a result file is
ALWAYS produced and one slow query can never abort the run. The internal
`evaluate_one` is guarded: formal held-out queries carry no oracle fields and
would otherwise KeyError — the run continues regardless.

## What is changed vs. the official example

1. `agent_env/scripts/solve_script_with_harness.py` — 5 minimal edits: accept
   `"tpcagent"` (validator + argparse choices + config selection), dispatch to
   `run_tpc_agent(...)` in `solve_query`, and guard `evaluate_one` for
   oracle-less held-out data.
2. `agent_env/scripts/tpc_agent_runner.py` (new) — builds TPCAgent + TPCLLM +
   WorldEnv once, runs each query under `func_timeout`, applies the budget and
   fallback policy above.
3. `chinatravel/agent/tpc_agent/` — our agent package (planner V6, hardened
   NL->DSL prompts + DSL canonicalizer, bilingual routing, deterministic
   fallback, and a 15-stage gated enrichment battery). The three newest stages
   target the tightened evaluator: `deoverlap` (chronology rethreading),
   `fixspace` (transport-chain rebuild via env goto), `mustpoi`
   (required-POI/hard-logic recovery: hotel windows, hotel meals, named
   restaurants, windowed attractions, cuisine/type sets, intercity swap, meal
   budget). Every stage is gated on the official evaluators with GENERATED
   constraints only — oracle fields are never read (stripped in
   `tpc_agent.py`, and absent from held-out data anyway).
4. Evaluator files synced to the latest ChinaTravel main (456b60a) so in-run
   gating matches formal grading.
5. Local dev data: `phase2_familiar_EN` plus an oracle-stripped
   `phase2_heldout_sim` split (`scripts/make_heldout_sim.py`) to reproduce
   held-out conditions locally.

## Validation

- End-to-end via the exact entry command on the oracle-stripped split with a
  local Qwen3.6 (Ollama): plan produced, result file written, evaluate_one
  guard exercised, zero parse failures.
- Live-NL scoring on the 100 familiarization queries with the real Qwen3.6-27B
  API (thinking off, oracle stripped before the agent sees the query):
  MicEPR 99.93 / MacEPR 99.00 / C-LPR 98.29 / FPR 93.00 / Overall 93.54
  under the latest evaluation code.


- Protocol-level SGLang simulation on macOS: `scripts/mock_sglang.py` serves the
  exact organizer contract (`http://127.0.0.1:30000/v1`, model `Qwen3.6-27B`,
  strict model-name check) backed by a local Ollama qwen3.6 (thinking off).
  The shipped package was verified against it with ZERO environment overrides —
  the same bare invocation the organizers use — producing a valid plan with
  0 parse failures.

## Determinism

temperature=0, fixed seed (`PENGUINS_SEED`), volatile counters stripped from
plans; the planner and enrichment are deterministic given identical LLM output.
